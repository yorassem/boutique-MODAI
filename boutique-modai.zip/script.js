function ajouterAuPanier(nomProduit) {
  const panier = document.getElementById('panier');
  const item = document.createElement('p');
  item.textContent = nomProduit + ' ajouté au panier';
  panier.appendChild(item);
}